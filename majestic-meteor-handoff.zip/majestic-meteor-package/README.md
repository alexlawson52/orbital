# Majestic Meteor — handoff notes

## What this is

A self-contained, single-file HTML/CSS/JS simulator for the **Majestic Meteor** mechanic in FFXIV's **M11S ("The Tyrant", AAC Heavyweight M3 Savage)**. It's part of a small suite of ad-hoc raid-mechanic trainers living in `orbital/` at the root of the `sysadmins/devops` repo — unrelated to that repo's actual purpose (an MkDocs docs site); this is just a convenient place to park the files, same precedent as the `aws/` and `elasticsearch-poc/` folders already there.

The sibling sim, **Orbital Omen** (`orbital/index.html`), covers an earlier mechanic in the same fight and is **100% complete** — do not touch it, it's out of scope for this work.

No build step. Open `majestic-meteor.html` directly, or serve `orbital/` with any static file server.

## Files in this package

```
majestic-meteor.html       the simulator itself
assets/role-icons.svg      standalone canonical copy of the role-icon sprite sheet
assets/hitbox-ring.svg     standalone canonical copy of the boss hitbox-ring asset
```

`majestic-meteor.html` has its own **vendored inline copies** of both SVG sprite sheets (in a `<defs>` block right after `<h1>`), because cross-file `<use href="assets/foo.svg#id">` is unreliable when the page is opened via `file://` instead of served over HTTP. **The two copies must be kept in sync by hand** — if you edit a symbol's geometry, edit it in both the standalone `assets/*.svg` file and the vendored copy inside `majestic-meteor.html`.

Drop this whole folder back into `orbital/` in the repo to resume (i.e. `majestic-meteor.html` at `orbital/majestic-meteor.html`, and the two SVGs merged into the existing `orbital/assets/`).

## The real mechanic (for context)

Majestic Meteor splits the arena into two islands (west/east) with the boss in the gap between them. Broad shape, from raid guides (Kitten ERP Guides, Icy Veins, NAUR, hardcoregamer, the FFXIV wiki — none of them fully agree on every detail, some of this is our own best-effort synthesis):

1. **Flatliner** — a raidwide knockback from the boss's position that physically splits the arena. Players must be positioned correctly (right side, within range) before it resolves or they die.
2. **Tower + tether phase** — 4 knockback towers spawn (2 per island, soaked in fixed role pairs), north/south portals spawn (telegraph lines), and up to 4 players get tethered to portals on the arena's outer edges. Tethered players may need to switch islands via their tower choice; everyone else stays put.
3. **Fire Breath phase** (not built) — untethered players bait prey markers near the boss, portals fire down their telegraphed lane, three sequential puddles drop per player baited at the edges, tethered players hold the outer ring.
4. **Second cycle** (not built) — the tower+tether and fire-breath sequence repeats once, with pairings already fixed from cycle 1.
5. **Closing sequence** (not built) — Massive Meteor (multi-hit stack), Arcadion Avalanche (knockup towers, move to the island opposite the boss's facing), Island Throw (dodge based on grip/swing direction), then the fight moves on.

We're building this **incrementally and interactively**, one decision point at a time, matching the user's own step-by-step direction each session — not a passive playback. Do not try to build ahead of what's been asked for.

## What's implemented right now

### 0. Role select (on load)
A grid of the 8 party-role icons (2 tanks, 2 healers, 4 DPS). Clicking one sets `state.role` for the whole session and shows the main sim. "change role" returns to this screen without losing anything else.

**Party structure** (fixed, not random):
| Group | Roles |
|---|---|
| West | MT (`role-blue-1`), H1 (`role-green-1`), D1 (`role-brown-1`), D3 (`role-brown-3`) |
| East | ST (`role-blue-2`), H2 (`role-green-2`), D2 (`role-brown-2`), D4 (`role-brown-4`) |

This grouping was wrong once already (D2/D3 swapped) and the user corrected it — the table above is confirmed correct, don't "fix" it back.

### 1. Flatliner (position + knockback)
- Arena starts as one solid platform (a `gapFill` rect covers the gap that will later open up), boss centered.
- Click anywhere to place your token (your own role's icon, glowing green). The other 7 party members' icons **cluster near the boss too**, same as you'd expect for a real pull about to eat a knockback — not scattered on their home islands. This was a specific fix: previously they were scattered on their islands pre-knockback and the user called it out as "weird."
- A yellow dashed **range ring** (radius = boss hitbox's own outer ring + 25px) with 16 outward-pointing arrow ticks marks the boss's danger range — a stand-in for the game's repeating "upward arrow" telegraph texture, which doesn't translate literally to a top-down view.
- Hitting "Next" fires the knockback: **you and all 7 NPCs animate outward from the boss simultaneously** (radial push, fixed distance `KNOCKBACK_DIST = 150`), the middle gap opens up (gapFill hidden), and outcomes are graded:
  - **Safe** (green) — landed on your correct home side.
  - **Wrong side** (still alive/green) — landed on the *other* island. Survivable, just a positioning mistake, not death.
  - **Dead** (red glow) — three ways to die: knocked into the gap, knocked off the arena's outer edge entirely, or you were standing outside the yellow range ring when Flatliner resolved (this last one is our own assumption — no guide spells out what actually happens if you're caught outside that ring, so we went with "death" per the user's explicit call).
- NPCs always resolve correctly (they're not being tested); only your own outcome matters.

### 2. Towers spawn
Click "Next" again: all 4 knockback towers appear as plain dashed circles — **deliberately no labels or icons on them**. The user was explicit: this is a sim to test whether the player knows their own assignment, so don't give the answer away visually.

Fixed tower→role pairing (a priority system, not random):
| Tower | Roles |
|---|---|
| top-left (west) | MT, D3 |
| bottom-left (west) | H1, D1 |
| top-right (east) | H2, D4 |
| bottom-right (east) | ST, D2 |

Each role also has an implicit fixed **row** (top or bottom) from this table — used later to compute the one uniquely-correct tower each round (see step 4).

### 3. Portals spawn
Click "Next" again:
- **North/south portals**: one per island, spawns above it. Each island splits into 2 even lanes (left/right); the portal centers within whichever lane it spawns in. **Both islands always share the same lane** (both left, or both right — never split). This is a "single line indicator" telegraph only — no fire/resolution yet.
  - This geometry was regressed once (collapsed to a single centered spot) and then over-corrected to 4 lane positions before landing back on the original, correct 2-lane-centered design. If you're tempted to change this again, don't, unless explicitly asked.
- **East/west tether portals**: **4 numbered positions per island** (1=top...4=bottom, on the arena's outer edges — west's portals sit left of the whole arena, east's sit right). Only one pair spawns per island per round: `{1,4}` (outer) or `{2,3}` (inner) — never both middle or both outer — and **the two islands always get the complementary pair** from each other (one gets outer, one gets inner). This is the real game's actual constraint (per Kitten ERP Guides) and was also regressed once during a rewrite — don't simplify it back down to "1 portal per side."
  - Each of the (up to 4) active portals independently tethers to **one random player from the full 8-person roster, any side** — so up to 4 distinct players get tethered, matching the guide's "four random players receive tethers."
  - Tethers are drawn as the same chevron arrow-chain ("`<<<<< | >>>>>`") built for Orbital Omen's proximity tether, pointing straight at the **actual on-board icon** of whichever player is targeted (your own live icon if it's you, or an NPC's current position). Do **not** go back to a floating text/icon label near the portal — the user explicitly rejected that as "giving away the answer" in a different way; the tether itself is the only indicator.
- Status text shows the decision logic in words (not yet which tower — see step 4):
  - No tether on you → "soak your assigned tower normally."
  - Tethered from your **own** side → "get knocked to the [other] platform" (you must switch islands).
  - Tethered from the **opposite** side → "get knocked back onto your own platform" (you must stay).

### 4. Choose your tower (the current final step)
The 4 towers become clickable. The correct tower each round is **your fixed row** (top/bottom, from the table in step 2) on **whichever side you actually need to end up on** (from the decision logic in step 3 — same side by default, opposite side if tethered from your own side).

- Click the right tower → it highlights green, confirmation text.
- Click the wrong tower → your pick highlights red, the *correct* tower also highlights green (so the answer is revealed after a miss, not before), your own icon glows red (dead), and the status text names the correct tower.

**This is where the build currently stops.** Nothing past this point exists yet.

## Key implementation details worth knowing before you touch the code

- **Coordinate system**: `SCALE = 2`, everything else derives from `SQUARE = 300 * SCALE`. The arena is a square split 35%/30%/35% (island/gap/island) by width (`ISLAND_FRAC = 0.35`).
- **State machine**: `state.phase` drives what's interactive — `placing` → `resolving` → `resolved` → `towers` → `choosing` → `chosen`. `nextBtn`'s click handler (`onNext`) dispatches based on phase for the first few steps; tower clicks are handled separately (`chooseTower`), gated on `phase === 'choosing'`.
- **Self icon**: `playerDot` is a `<use>` element (not a plain circle) referencing whichever role the player picked, sized via `ICON_SIZE = 30`, styled with a green (`.self-icon`) or red (`.self-icon.dead`) glow filter. `placeDot()` and `animateMany()` both just update `playerPos` and re-run the same positioning logic — don't reintroduce `cx`/`cy`-based positioning, it's `x`/`y` (top-left corner, offset by half the icon size) now.
- **NPCs**: `setupParty()` builds/repositions the other 7 role icons each round — pre-knockback they cluster randomly near the boss (within a fraction of `RANGE_R`), and a `home` position (random spot within their own island) is precomputed so `fireKnockback()`'s `animateMany()` can fling everyone (player + 7 NPCs) outward in one synchronized tween. `entityPos(roleId)` resolves either the player's live position or an NPC's current position — this is what tethers point at.
- **Randomization philosophy**: the user has been explicit (going back to Orbital Omen) that they want genuine unpredictability over curated fixed patterns — "let people cycle through to be surprised, the actual encounter won't be static." Keep leaning that way for anything not already pinned down by a specific rule (tower pairing, side grouping, tether-pairing constraint are all fixed/real; everything else — who gets tethered, which lane, which pair is outer/inner, NPC scatter positions — should stay randomized per round).
- **Death vs. alive convention**: established back in Orbital Omen and carried forward — a wrong answer doesn't hard-stop the sim, it's graded and shown, and the sequence is considered "resolved" either way (the player can always see what the *correct* answer would have been).

## Known environment gotchas (don't rediscover these the hard way)

- **`file://` vs served**: always test via a local server (`python3 -m http.server <port>` from `orbital/`) plus the Claude Browser tool — opening the file directly in Claude's Browser pane renders a static, non-interactive snapshot (JS doesn't execute), and cross-file `<use>` references don't resolve reliably over `file://` either (hence the vendored SVG defs, see above).
- **`requestAnimationFrame` + hidden Browser pane**: if the Browser pane isn't actually visible/composited (`document.hidden === true`), rAF-based animations (the knockback tweens) can stall indefinitely — a plain `computer` screenshot call forces a compositing frame and lets queued rAF callbacks flush. If an automated test looks "stuck" after clicking Next, take a screenshot before concluding something's broken.
- **`<meta charset="utf-8">`**: this file has one at the very top. Without it, em dashes (`—`) in status text render as mojibake (`â€"`) when served without an explicit charset header. Don't remove it.
- **SVG filter + `display:none` ancestor**: the vendored sprite-defs wrapper `<svg>` uses `style="position:absolute;width:0;height:0;overflow:hidden"`, not `display:none` — the hitbox-ring's `feDropShadow` filter silently fails to render if its containing tree is `display:none`. This bit us once already; don't "simplify" it back.

## Suggested next steps (not started, ask before assuming scope)

In roughly the order they'd naturally come up, per the mechanic breakdown above:
1. Fire Breath phase: prey-marker baiting near the boss for untethered players, portal fire down the telegraphed N/S lane, sequential edge puddles.
2. Second cycle of towers+tethers+fire, with pairings carried over from cycle 1.
3. Closing sequence: Massive Meteor stack, Arcadion Avalanche, Island Throw.

The user has been directing this one small step at a time across many turns — don't build multiple steps ahead in one go even if the shape seems obvious from this doc. Confirm scope before large structural changes, and check in if a past instruction and a new one seem to conflict rather than guessing which one wins.
